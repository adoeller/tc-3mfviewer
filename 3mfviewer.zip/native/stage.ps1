param([ValidateSet('32','64')][string]$Target='64')
$ErrorActionPreference='Stop'
# Stages project-local runtime files only; never copies to Total Commander.
$nativeRoot=$PSScriptRoot
$projectRoot=Split-Path $nativeRoot -Parent
$probeRoot=Join-Path $projectRoot 'test\occt_probe'
foreach ($buildTarget in @('32','64')) {
    $source=Join-Path $probeRoot ('build'+$buildTarget+'\Release\step_import.dll')
    if (-not (Test-Path -LiteralPath $source)) { throw ('Missing build: '+$source) }
}
foreach ($buildTarget in @('32','64')) {
    $dest=Join-Path $nativeRoot ('win'+$buildTarget)
    New-Item -ItemType Directory -Force -Path $dest | Out-Null
    Copy-Item -LiteralPath (Join-Path $probeRoot ('build'+$buildTarget+'\Release\step_import.dll')) -Destination $dest
}
$vendor=Join-Path $probeRoot 'vendor\occt-import-js'
Copy-Item -LiteralPath (Join-Path $vendor 'dist\license.occt-import-js.txt') -Destination $nativeRoot
Copy-Item -LiteralPath (Join-Path $vendor 'occt\LICENSE_LGPL_21.txt') -Destination $nativeRoot
Copy-Item -LiteralPath (Join-Path $vendor 'occt\OCCT_LGPL_EXCEPTION.txt') -Destination $nativeRoot
Get-ChildItem (Join-Path $nativeRoot 'win*') -File -Recurse | Select-Object FullName,Length
# Both build products remain in architecture-specific staging directories.
# The runtime itself is searched beside the WLX; only one architecture can
# occupy that filename in a shared project directory at a time.
Copy-Item -LiteralPath (Join-Path $nativeRoot ('win'+$Target+'\step_import.dll')) -Destination $projectRoot
